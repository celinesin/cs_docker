
int MAIN__(void) { return 0; }
